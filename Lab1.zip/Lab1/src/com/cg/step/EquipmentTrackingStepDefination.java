package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CompTrak;
import com.cg.bean.Equipment;
import com.cg.bean.Location;
import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class EquipmentTrackingStepDefination {

	private WebDriver driver;
	private CompTrak compTrak;
	private Equipment equip;
	private Location location;
	private User user;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}
	
	@Given("^User is on Login form$")
	public void user_is_on_Login_form() throws Throwable {
		driver.get("file:///C:/Users/adsinha/Desktop/Module%204/Lab1/html/index.html");
		user = new User();
		PageFactory.initElements(driver, user);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is on login form$")
	public void user_is_on_login_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^User selects authorization Type$")
	public void user_selects_authorization_Type() throws Throwable {
		user.selectType(2);
	}

	@Then("^Validate authorization Type$")
	public void validate_authorization_Type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^User enters UserId$")
	public void user_enters_UserId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^Validate UserId$")
	public void validate_UserId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^Validate Password$")
	public void validate_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^User submits form$")
	public void user_submits_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^show successful alert$")
	public void show_successful_alert() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is on Equipment form$")
	public void user_is_on_Equipment_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid purchaseMethod$")
	public void user_enters_invalid_purchaseMethod() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Purchase Method'$")
	public void display_Please_fill_the_Purchase_Method() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid sequenceNumber$")
	public void user_enters_invalid_sequenceNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Sequence Number'$")
	public void display_Please_fill_the_Sequence_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid equipmentCode$")
	public void user_enters_invalid_equipmentCode() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Equipment Code'$")
	public void display_Please_fill_the_Equipment_Code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid deptId$")
	public void user_enters_invalid_deptId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Dept ID'$")
	public void display_Please_fill_the_Dept_ID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid useStatus$")
	public void user_enters_invalid_useStatus() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Use Status'$")
	public void display_Please_fill_the_Use_Status() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid costCenter$")
	public void user_enters_invalid_costCenter() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Cost Center'$")
	public void display_Please_fill_the_Cost_Center() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid installDate$")
	public void user_enters_invalid_installDate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Install Date'$")
	public void display_Please_fill_the_Install_Date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid auditIndicator$")
	public void user_enters_invalid_auditIndicator() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Audit Indicator'$")
	public void display_Please_fill_the_Audit_Indicator() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid auditDate$")
	public void user_enters_invalid_auditDate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Audit Date'$")
	public void display_Please_fill_the_Audit_Date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid stock$")
	public void user_enters_invalid_stock() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Stock'$")
	public void display_Please_fill_the_Stock() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^User is on Computer form$")
	public void user_is_on_Computer_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid computerName$")
	public void user_enters_invalid_computerName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Computer Name'$")
	public void display_Please_fill_the_Computer_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid diskCapacity$")
	public void user_enters_invalid_diskCapacity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Disk Capacity'$")
	public void display_Please_fill_the_Disk_Capacity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid totalInstalledMemory$")
	public void user_enters_invalid_totalInstalledMemory() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Total Installed Memory'$")
	public void display_Please_fill_the_Total_Installed_Memory() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid networkCardNumber$")
	public void user_enters_invalid_networkCardNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Network Card Number'$")
	public void display_Please_fill_the_Network_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid networkCardManufacturer$")
	public void user_enters_invalid_networkCardManufacturer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Network Card Manufacturer'$")
	public void display_Please_fill_the_Network_Card_Manufacturer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid freeSpace$")
	public void user_enters_invalid_freeSpace() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Free Space'$")
	public void display_Please_fill_the_Free_Space() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid operatingSystem$")
	public void user_enters_invalid_operatingSystem() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the Operating System'$")
	public void display_Please_fill_the_Operating_System() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid osVersion$")
	public void user_enters_invalid_osVersion() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^display 'Please fill the OS Version'$")
	public void display_Please_fill_the_OS_Version() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
