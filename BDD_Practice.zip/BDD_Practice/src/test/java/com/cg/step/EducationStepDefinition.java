package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {

	private WebDriver driver;

	private Education education;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		
	}

//	@After
//	public void destroy() {
//		driver.quit();
//	}

	@Given("^User is on Educational Details form$")
	public void user_is_on_Educational_Details_form() throws Throwable {
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/adsinha/Spring/BDD_Practice/html/EducationalDetails.html");
		Thread.sleep(2000);
		education = new Education();
		PageFactory.initElements(driver, education);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
		

	}

	@Then("^page should be loaded Edu$")
	public void page_should_be_loaded_Edu() throws Throwable {
		if(driver.getTitle().equals("Educational Details")) {
			System.out.println("Title of the page is : " + driver.getTitle());
		}
	}

	@When("^user enters invalid graduation$")
	public void user_enters_invalid_graduation() throws Throwable {
		education.selectGraduation(0);
	}

	@Then("^display 'Please Select the Graduation'$")
	public void display_Please_Select_the_Graduation() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid percentage$")
	public void user_enters_invalid_percentage() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("");
	}

	@Then("^display 'Please fill the Percentage'$")
	public void display_Please_fill_the_Percentage() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid passingYear$")
	public void user_enters_invalid_passingYear() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("78%");
		education.setPassingYear("");
	}

	@Then("^display 'Please fill the Passing Year'$")
	public void display_Please_fill_the_Passing_Year() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid projectName$")
	public void user_enters_invalid_projectName() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("78%");
		education.setPassingYear("2015");
		education.setProjectName("");
	}

	@Then("^display 'Please fill the Project Name'$")
	public void display_Please_fill_the_Project_Name() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid technologies$")
	public void user_enters_invalid_technologies() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("78%");
		education.setPassingYear("2015");
		education.setProjectName("project");
		education.selectTechnologies(0);
	}

	@Then("^display 'Please Select the Technologies'$")
	public void display_Please_Select_the_Technologies() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid otherTechnologies$")
	public void user_enters_invalid_otherTechnologies() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("78%");
		education.setPassingYear("2015");
		education.setProjectName("project");
		education.selectTechnologies(0);
		education.setOtherTechnologies("");
	}

	@Then("^display 'Please fill the Other Technologies'$")
	public void display_Please_fill_the_Other_Technologies() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User makes payment$")
	public void user_makes_payment() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("78%");
		education.setPassingYear("2015");
		education.setProjectName("project");
		education.selectTechnologies(0);
		education.setOtherTechnologies("other");
	}

	@Then("^show successful payment alert$")
	public void show_successful_payment_alert() throws Throwable {
		education.clickNaext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
}
