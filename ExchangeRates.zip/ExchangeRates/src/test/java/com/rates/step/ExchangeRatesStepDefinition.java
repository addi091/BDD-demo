/**
 * 
 */
package com.rates.step;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

import com.rates.bean.ExchangeRates;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author aditya sinha
 *
 */
public class ExchangeRatesStepDefinition {

	private ExchangeRates exchangeRates;

	BufferedReader rd;
	OutputStreamWriter wr;

	@Given("^rates API for Latest Foreign Exchange rates$")
	public void rates_API_for_Latest_Foreign_Exchange_rates() throws Throwable {
		exchangeRates = new ExchangeRates();
		exchangeRates.setBase("USD");
		exchangeRates.setDate("2020-11-02");
		exchangeRates.setRates("74.00");
		System.out.println(exchangeRates);

	}

	@When("^the API is available$")
	public void the_API_is_available() throws Throwable {
		URL url = new URL("https://api.ratesapi.io/api/latest");
		URLConnection conn = url.openConnection();
		conn.setDoOutput(true);
		wr = new OutputStreamWriter(conn.getOutputStream());
		wr.flush();

		// Get the response
		rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String line;
		while ((line = rd.readLine()) != null) {
			System.out.println(line);
		}

	}

	@Then("^an automated test suite should run which will assert the success status of the response$")
	public void an_automated_test_suite_should_run_which_will_assert_the_success_status_of_the_response()
			throws Throwable {

	}

}
