package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {

	@FindBy(id="grad")
	private WebElement graduation;
	
	@FindBy(id="perc")
	private WebElement percentage;
	
	@FindBy(id="passYear")
	private WebElement passingYear;
	
	@FindBy(id="projName")
	private WebElement projectName;
	
	@FindBy(id="tech")
	private WebElement technologies;
	
	@FindBy(id="otherTech")
	private WebElement otherTechnologies;

	@FindBy(id="makePayement")
	private WebElement makePayement;
	
	public String getGraduation() {
		return graduation.getAttribute("value");
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);  
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage); 
	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getTechnologies() {
		return technologies.getAttribute("value");
	}

	public void setTechnologies(String technologies) {
		this.technologies.sendKeys(technologies);
	}

	public String getOtherTechnologies() {
		return otherTechnologies.getAttribute("value");
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}
	
	public void selectGraduation(int i) {
		Select select = new Select(graduation);
		select.selectByIndex(i);
	}
	public void selectTechnologies(int i) {
		Select select = new Select(technologies);
		select.selectByIndex(i);
	}
	
	public void clickNaext() {
		makePayement.click();
	}
}
