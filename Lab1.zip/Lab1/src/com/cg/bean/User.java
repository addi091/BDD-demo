package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class User {
	
	
	
	@FindBy(id="txtsequenceNumber")
	WebElement userId;
	
	@FindBy(id="txtsequenceNumber")
	WebElement userPass;
	
	@FindBy(id="txtsequenceNumber")
	WebElement authorizationType;
	
	@FindBy(id = "login")
	private WebElement login;    // new added

	public String getUserId() {
		return userId.getAttribute("value");
	}

	

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}



	public String getUserPass() {
		return userPass.getAttribute("value");
	}

	public void setUserPass(String userPass) {
		this.userPass.sendKeys(userPass);
	}

	public String getAuthorizationType() {
		return authorizationType.getAttribute("value");
	}

	public void setAuthorizationType(String authorizationType) {
		this.authorizationType.sendKeys(authorizationType); 
	}
	
	public String getLogin() {
		return login.getAttribute("value");
	}

	public void setLogin(String login) {
		this.login.sendKeys(login);
	}
	public void selectType(int idx) {
		Select select = new Select(authorizationType);
		select.selectByIndex(idx);
	}
	public void clickLogin() {
	  login.click();
	}
}
