package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Location {
	
	@FindBy(name="txtlocation")
	WebElement location;
	
	@FindBy(name="txtlocationId")
	WebElement locationId;

	public WebElement getLocation() {
		return location;
	}

	public void setLocation(WebElement location) {
		this.location = location;
	}

	public WebElement getLocationId() {
		return locationId;
	}

	public void setLocationId(WebElement locationId) {
		this.locationId = locationId;
	}
	
	
	
}
