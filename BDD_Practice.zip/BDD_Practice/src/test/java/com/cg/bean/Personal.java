package com.cg.bean;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	
	@FindBy(id="txtFirstName")
	private WebElement firstName;
	
	@FindBy(id="txtLastName")
	private WebElement lastName;
	
	@FindBy(id="txtEmail")
	private WebElement email;
	
	@FindBy(id="txtPhone")
	private WebElement phone;
	
	@FindBy(id="txtA1")
	private WebElement address1;
	
	@FindBy(id="txtA2")
	private WebElement address2;
	
	@FindBy(name="city")
	private WebElement city;
	
	@FindBy(name="state")
	private WebElement state;

	@FindBy(id="next")
	private WebElement next;
	
	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return this.phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public String getAddress1() {
		return this.address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public String getAddress2() {
		return this.address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}
	
	

	public String getCity() {
		return this.city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city); 
	}

	public String getState() {
		return this.state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state); 
	}

	public void selectCity(int i) {
		Select select = new Select(city);
		select.selectByIndex(i);
	}
	
	public void selectState(int i) {
		Select select = new Select(state);
		select.selectByIndex(i);
	}

	public void clickNext() {
		next.click();
	}
}
