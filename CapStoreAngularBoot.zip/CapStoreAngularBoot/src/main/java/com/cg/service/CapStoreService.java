package com.cg.service;

import java.util.Optional;

import com.cg.entity.MostView;
import com.cg.entity.Product;

public interface CapStoreService {
	
	public void addProduct(Product p);
	
	Iterable<Product> getAll();
	
	Optional <MostView> getMostViewed(int id);
	
	public void addMostview(MostView m);

}
