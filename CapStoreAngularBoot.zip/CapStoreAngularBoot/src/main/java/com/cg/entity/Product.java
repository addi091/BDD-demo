package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "product")
@SequenceGenerator(name = "pseq", sequenceName = "product_seq", initialValue = 101)
public class Product {
	@Id
	@Column(name = "product_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pseq")
	private int id;

	@Transient
	private int catId;

	@Column(name = "product_name", length = 50)
	private String name;

	@Column(name = "product_brand", length = 50)
	private String brand;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@JsonIgnore
	public Category getCategory() {
		return categoryFromProduct;
	}

	public void setCategory(Category category) {
		this.categoryFromProduct = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	@JsonIgnore
	public List<Inventory> getInventory() {
		return inventoryFromProduct;
	}

	public void setInventory(List<Inventory> inventory) {
		this.inventoryFromProduct = inventory;
	}

	public void addInventory(Inventory inventory) {
		inventory.setProduct(this);
		this.getInventory().add(inventory);
	}

	public Category getCategoryFromProduct() {
		return categoryFromProduct;
	}

	public void setCategoryFromProduct(Category categoryFromProduct) {
		this.categoryFromProduct = categoryFromProduct;
	}

	public List<Inventory> getInventoryFromProduct() {
		return inventoryFromProduct;
	}

	public void setInventoryFromProduct(List<Inventory> inventoryFromProduct) {
		this.inventoryFromProduct = inventoryFromProduct;
	}

	public MostView getMostView() {
		return mostView;
	}

	public void setMostView(MostView mostView) {
		this.mostView = mostView;
	}

	/************** Relationships ******************/
	@JsonBackReference(value = "product-category")
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "category_id")
	private Category categoryFromProduct;

	@OneToMany(mappedBy = "productFromInventory", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Inventory> inventoryFromProduct = new ArrayList<Inventory>();

	@OneToOne(mappedBy = "productFromMostView", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private MostView mostView;

}