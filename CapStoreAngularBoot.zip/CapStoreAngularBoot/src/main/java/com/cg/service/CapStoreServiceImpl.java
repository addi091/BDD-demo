package com.cg.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.MostView;
import com.cg.entity.Product;
import com.cg.repo.CapStoreMostViewedRepo;
import com.cg.repo.CapStoreProductRepo;

@Service
@Transactional
public class CapStoreServiceImpl implements CapStoreService {
	
	@Autowired
	private CapStoreProductRepo repo;
	
	@Autowired
	private CapStoreMostViewedRepo repom;
	

	@Override
	public void addProduct(Product p) {
       repo.save(p);		
	}

	@Override
	public Iterable<Product> getAll() {
		return repo.findAll();
	}

	@Override
	public Optional<MostView> getMostViewed(int id) {
		return repom.findById(id);
	}

	@Override
	public void addMostview(MostView m) {
       repom.save(m);		
	}
	
	

}
