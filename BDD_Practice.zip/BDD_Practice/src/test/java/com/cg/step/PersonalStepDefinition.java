package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;

	private Personal personal;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		
	}

//	@After
//	public void destroy() {
//		driver.quit();
//	}

	
	@Given("^User is on Personal Details form$")
	public void user_is_on_Personal_Details_form() throws Throwable {
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/adsinha/Spring/BDD_Practice/html/PersonalDetails.html");
		Thread.sleep(2000);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}
	
	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		if(driver.getTitle().equals("Personal Details")) {
			System.out.println("Title of the page is : " + driver.getTitle());
		}
	}


	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
         personal.setFirstName("");
         Thread.sleep(2000);
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		personal.setFirstName("aditya");
		personal.setLastName("");
		Thread.sleep(2000);
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("");
		Thread.sleep(2000);
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid phone$")
	public void user_enters_invalid_phone() throws Throwable {
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("addi091@gmail.com");
		personal.setPhone("");
		Thread.sleep(2000);
	}

	@Then("^display 'Please enter valid Contact no\\.'$")
	public void display_Please_enter_valid_Contact_no() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid address(\\d+)$")
	public void user_enters_invalid_address(int arg1) throws Throwable {
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("addi091@gmail.com");
		personal.setPhone("7030179024");
		personal.setAddress1("");
		Thread.sleep(2000);
	}

	@Then("^display 'Please fill the Address Line (\\d+)'$")
	public void display_Please_fill_the_Address_Line(int arg1) throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid address two$")
	public void user_enters_invalid_auditIndicator() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("addi091@gmail.com");
		personal.setPhone("7030179024");
		personal.setAddress1("manohar PG, 203");
		personal.setAddress2("");
		Thread.sleep(2000);
	}
	
	@Then("^display 'Please fill the Address Line'$")
	public void display_Please_fill_the_Address_Line_Two(int arg1) throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("addi091@gmail.com");
		personal.setPhone("7030179024");
		personal.setAddress1("manohar PG, 203");
		personal.setAddress2("airoli");
		personal.selectCity(0);
		Thread.sleep(2000);
	}

	@Then("^display 'Please Select the City'$")
	public void display_Please_Select_the_City() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}



	@When("^user enters invalid state$")
	public void user_enters_invalid_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("addi091@gmail.com");
		personal.setPhone("7030179024");
		personal.setAddress1("manohar PG, 203");
		personal.setAddress2("airoli");
		personal.selectCity(1);
		personal.selectState(0);
		Thread.sleep(2000);
	}

	@Then("^display 'Please Select the State'$")
	public void display_Please_Select_the_State() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User submits form$")
	public void user_submits_form() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		personal.setFirstName("aditya");
		personal.setLastName("sinha");
		personal.setEmail("addi091@gmail.com");
		personal.setPhone("7030179024");
		personal.setAddress1("manohar PG, 203");
		personal.setAddress2("airoli");
		personal.selectCity(1);
		personal.selectState(1);
		Thread.sleep(2000);
	
	}

	@Then("^show successful register alert$")
	public void show_successful_register_alert() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
}
