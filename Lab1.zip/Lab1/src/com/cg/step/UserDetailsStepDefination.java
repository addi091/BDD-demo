package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserDetailsStepDefination {

	private WebDriver driver;
	private User user;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}
	
	@Given("^User is on Login form$")
	public void user_is_on_Login_form() throws Throwable {
		driver.get("file:///C:/Users/adsinha/Desktop/Module%204/Lab1/html/login.html");
		Thread.sleep(5000);
		user = new User();
		PageFactory.initElements(driver, user);
	}



	@When("^User selects authorization Type$")
	public void user_selects_authorization_Type() throws Throwable {
		user.selectType(2);
	}

	@Then("^Validate authorization Type$")
	public void validate_authorization_Type() throws Throwable {
		user.clickLogin();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^User enters UserId$")
	public void user_enters_UserId() throws Throwable {
		user.selectType(2);
		user.setUserId("123");
	}

	@Then("^Validate UserId$")
	public void validate_UserId() throws Throwable {
		user.clickLogin();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		user.selectType(2);
		user.setUserId("1234");
		user.setUserPass("abc");
	}

	@Then("^Validate Password$")
	public void validate_Password() throws Throwable {
		user.clickLogin();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}
	@When("^User login form$")
	public void user_login_form() throws Throwable {
		user.selectType(2);
		user.setUserId("1234");
		user.setUserPass("abcd");
	}

	@Then("^show successful login alert$")
	public void show_successful_login_alert() throws Throwable {
		user.clickLogin();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}
}
