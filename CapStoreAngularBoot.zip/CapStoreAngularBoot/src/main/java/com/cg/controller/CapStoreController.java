package com.cg.controller;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.MostView;
import com.cg.entity.Product;
import com.cg.service.CapStoreService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CapStoreController {

	@Autowired
	private CapStoreService service;

	@GetMapping(path = "/all")
	public Iterable<Product> getAll() {
		Iterable<Product> p = service.getAll();
		
		return p;
	}

	@GetMapping(path = "/product/{id}")
	public ResponseEntity<MostView> get(@PathVariable("id") int id) {
		try {
			Optional<MostView> m = service.getMostViewed(id);
			return new ResponseEntity<MostView>(HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity("Sorry. No Product Found", HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping(path = "/add", consumes = "application/json", produces = "application/json")
	public Product add(@RequestBody Product p) {
		service.addProduct(p);
		return p;
	}
	
	@PostMapping(path = "/addm", consumes = "application/json", produces = "application/json")
	public MostView add(@RequestBody MostView m) {
		service.addMostview(m);
		return m;
	}
}
