package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CompTrak;
import com.cg.bean.Equipment;
import com.cg.bean.Location;
import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentTrackingStepDefination {

	private WebDriver driver;
	private Equipment equip;
	private Location location;
	

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Equipment form$")
	public void user_is_on_Equipment_form() throws Throwable {
		driver.get("file:///C:/Users/adsinha/Desktop/Module%204/Lab1/html/equipment.html");
		Thread.sleep(5000);
		equip = new Equipment();
		PageFactory.initElements(driver, equip);
	}

	@When("^user enters invalid purchaseMethod$")
	public void user_enters_invalid_purchaseMethod() throws Throwable {
		equip.setPurchaseMethod("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Purchase Method'$")
	public void display_Please_fill_the_Purchase_Method() throws Throwable {
		String expectedMessage = "Please fill the Purchase Method";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid sequenceNumber$")
	public void user_enters_invalid_sequenceNumber() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Sequence Number'$")
	public void display_Please_fill_the_Sequence_Number() throws Throwable {
		String expectedMessage = "Please fill the Sequence Number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid equipmentCode$")
	public void user_enters_invalid_equipmentCode() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Equipment Code'$")
	public void display_Please_fill_the_Equipment_Code() throws Throwable {
		String expectedMessage = "Please fill the Equipment Code";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid deptId$")
	public void user_enters_invalid_deptId() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Dept ID'$")
	public void display_Please_fill_the_Dept_ID() throws Throwable {
		String expectedMessage = "Please fill the Dept ID";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid useStatus$")
	public void user_enters_invalid_useStatus() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Use Status'$")
	public void display_Please_fill_the_Use_Status() throws Throwable {
		String expectedMessage = "Please fill  the Use Status";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid costCenter$")
	public void user_enters_invalid_costCenter() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Cost Center'$")
	public void display_Please_fill_the_Cost_Center() throws Throwable {
		String expectedMessage = "Please fill the Cost Center";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid installDate$")
	public void user_enters_invalid_installDate() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Install Date'$")
	public void display_Please_fill_the_Install_Date() throws Throwable {
		String expectedMessage = "Please fill the Install Date";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid auditIndicator$")
	public void user_enters_invalid_auditIndicator() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("12/4/2019");
		equip.setAuditIndictor("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Audit Indicator'$")
	public void display_Please_fill_the_Audit_Indicator() throws Throwable {
		String expectedMessage = "Please fill  the Audit Indicator";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid auditDate$")
	public void user_enters_invalid_auditDate() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("12/4/2019");
		equip.setAuditIndictor("yes");
		equip.setAuditDate("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Audit Date'$")
	public void display_Please_fill_the_Audit_Date() throws Throwable {
		String expectedMessage = "Please fill the Audit Date";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid stock$")
	public void user_enters_invalid_stock() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("");
		equip.clickNextButton();
	}

	@Then("^display 'Please fill the Stock'$")
	public void display_Please_fill_the_Stock() throws Throwable {
		String expectedMessage = "Please fill the Stock";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^user enters invalid location$")
	public void user_enters_invalid_location() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		location.setLocation("");
	}

	@Then("^display 'Please fill the Location'$")
	public void display_Please_fill_the_Location() throws Throwable {
		String expectedMessage = "Please fill the Location";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid locationId$")
	public void user_enters_invalid_locationId() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		location.setLocation("0");
		location.setLocationId("");
	}

	@Then("^display 'Please fill the Location ID'$")
	public void display_Please_fill_the_Location_ID() throws Throwable {
		String expectedMessage = "Please fill the Location ID";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^User register form$")
	public void user_register_form() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus("0");
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		location.setLocation("0");
		location.setLocationId("123");
	}

	@Then("^show successful register alert$")
	public void show_successful_register_alert() throws Throwable {
		equip.clickNextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}
}
	
